<?php

if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

class AdminM extends CI_Model{
	public function __construct(){
		parent::__construct();
	}

	public function get_pengguna(){
		$this->db->select('*');
		$this->db->from('pengguna P');
		$this->db->join('jabatan J','J.id_jabatan = P.id_jabatan','left');
		$this->db->order_by('J.id_jabatan');
		return $this->db->get();
	}
}