<div class="col-xl-12">
                                <!-- Tabs Dropdown -->
                                <div class="widget has-shadow">
                                    <div class="widget-header bordered no-actions d-flex align-items-center">
                                        <h4>Pelaporan</h4>
                                    </div>
                                    <div class="widget-body">
                                        <ul class="nav nav-tabs" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" id="drop-tab-1" data-toggle="tab" href="#d-tab-1" role="tab" aria-selected="true">ILR</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="drop-tab-2" data-toggle="tab" href="#d-tab-2" role="tab" aria-selected="false">PMK</a>
                                            </li>
                                            <li class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                                                    Pemadam
                                                    <i class="ion-android-arrow-dropdown"></i>
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" id="nav-dropdown1-tab" href="#nav-dropdown1" role="tab" data-toggle="tab">Dropdown 1</a>
                                                    <a class="dropdown-item" id="nav-dropdown2-tab" href="#nav-dropdown2" role="tab" data-toggle="tab">Dropdown 2</a>
                                                </div>
                                            </li>
                                        </ul>                                                Mauris venenatis rutrum augue vulputate fringilla. Aliquam euismod tempor neque. Ut urna tortor, mattis vitae gravida in, consectetur at est. Nulla eu purus et justo porttitor luctus. Cras sed urna vitae quam interdum varius vel sollicitudin lectus. Proin ullamcorper lacinia justo, eget porta odio egestas sed.

                                        <div class="tab-content pt-3">
                                            <div class="tab-pane fade show active" id="d-tab-1" role="tabpanel" aria-labelledby="drop-tab-1">
                                                Nam sagittis nec velit vitae molestie. Donec eget luctus sem. Nullam tortor tortor, consequat id lacinia nec, tempus in diam. Phasellus vel molestie purus, ac hendrerit risus. Phasellus non purus lacinia purus fringilla hendrerit. Sed pharetra odio a ante volutpat aliquam id non lacus.
                                            </div>
                                            <div class="tab-pane fade" id="d-tab-2" role="tabpanel" aria-labelledby="drop-tab-2">
                                            </div>
                                            <div class="tab-pane fade" id="nav-dropdown1" role="tabpanel" aria-labelledby="nav-dropdown1-tab">
                                                Deserunt officia id Lorem nostrud aute id commodo elit eiusmod enim irure amet eiusmod qui reprehenderit nostrud tempor. Fugiat ipsum excepteur in aliqua non et quis aliquip ad irure in labore cillum elit enim. Consequat aliquip incididunt ipsum et minim laborum laborum laborum et cillum labore.
                                            </div>
                                            <div class="tab-pane fade" id="nav-dropdown2" role="tabpanel" aria-labelledby="nav-dropdown2-tab">
                                                Proident incididunt esse qui ea nisi ullamco aliquip nostrud velit sint duis. Aute culpa aute cillum sit consectetur mollit minim non reprehenderit tempor. Occaecat amet consectetur aute esse ad ullamco ad commodo mollit reprehenderit esse in consequat.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Tabs Dropdown -->
                            </div>