<div class="container-fluid">
	<!-- Begin Page Header-->
	<div class="row">
		<div class="page-header">
			<div class="d-flex align-items-center">
				<h2 class="page-header-title">Data Pegawai</h2>
			</div>
		</div>
	</div>
	<!-- End Page Header -->
	<div class="row">
		<div class="col-xl-12">
			<!-- Sorting -->
			<div class="widget has-shadow">
				<div class="widget-body">
					<div class="widget-body">
						<ul class="nav nav-tabs" id="example-one" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="base-tab-1" data-toggle="tab" href="#tab-1" role="tab" aria-controls="tab-1" aria-selected="true">Pegawai</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="base-tab-2" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tab-2" aria-selected="false">User</a>
							</li>
						</ul>
						<div class="tab-content pt-3">
							<div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="base-tab-1">
								<div class="text-right">
									<a href="#" data-toggle="modal" data-target="#tambahpegawai" class="btn btn-md btn-primary"><i class="la la-plus"></i> Tambah</a>
									<!-- 	<input type="button" data-toggle="modal" data-target="#tambahpegawai" name="tambah" value="Tambah" class="btn btn-md btn-info"> -->
								</div> <br>
								<!-- <?php echo print_r($data_pengguna)?> -->
								<div class="table-responsive">
									<table id="myTable" class="table mb-0">
										<thead>
											<tr>
												<th class="text-center">No</th>
												<th class="text-center">Nama</th>
												<th class="text-center">Email</th>
												<th class="text-center">Jabatan</th>
												<th class="text-center">Status</th>
												<th class="text-center">Aksi</th>
											</tr>
										</thead>
										<tbody>
											<?php
											$no=0;
											foreach ($data_pengguna as $pengguna) {
												$no++;
												if($pengguna->id_jabatan <= 4){
													?>
													<tr>
														<td class="text-center"><?php echo $no;?></td>
														<td><?php echo $pengguna->nama_pengguna?></td>
														<td><?php echo $pengguna->email_pengguna?></td>
														<td><?php echo $pengguna->nama_jabatan?></td>
														<td class="text-center">
															<span style="width:100px;"><span class="badge-text badge-text-small success" ><?php echo $pengguna->status_akun?></span></span>
														</td>
														<td class="text-center">
															<a href="#" class="btn btn-success btn-sm" title="Ubah"><i class="la la-pencil"></i></i></a>
															<!-- <a href="#" class="btn btn-danger btn-sm" title="Hapus"><i class="la la-trash"></i></i></a> -->
															<a href="#" class="btn btn-info btn-sm" title="aktif"><i class="la la-check"></i></i></a>
															<a href="#" class="btn btn-danger btn-sm" title="non-aktif"><i class="la la-power-off"></i></i></a>
														</td>
													</tr>
													<?php
												}
											}
											?>
										</tbody>
									</table>
								</div>
							</div>
							<div class="tab-pane fade show" id="tab-2" role="tabpanel" aria-labelledby="base-tab-2">
								<div class="table-responsive">
									<table id="myTable2" class="table mb-0">
										<thead>
											<tr>
												<th class="text-center">No</th>
												<th class="text-center">Nama</th>
												<th class="text-center">Email</th>
												<th class="text-center">Jabatan</th>
												<th class="text-center">Status</th>
												<th class="text-center">Aksi</th>
											</tr>
										</thead>
										<tbody>
											<?php
											$i=0;
											foreach ($data_pengguna as $pengguna) {
												$i++;
												if($pengguna->id_jabatan > 4){
													?>
													<tr>
														<td class="text-center"><?php echo $i;?></td>
														<td><?php echo $pengguna->nama_pengguna?></td>
														<td><?php echo $pengguna->email_pengguna?></td>
														<td><?php echo $pengguna->nama_jabatan?></td>
														<td class="text-center">
															<span style="width:100px;"><span class="badge-text badge-text-small success" ><?php echo $pengguna->status_akun?></span></span>
														</td>
														<td class="text-center">
															<a href="#" class="btn btn-success btn-sm" title="Ubah"><i class="la la-pencil"></i></i></a>
															<!-- <a href="#" class="btn btn-danger btn-sm" title="Hapus"><i class="la la-trash"></i></i></a> -->
															<a href="#" class="btn btn-info btn-sm" title="aktif"><i class="la la-check"></i></i></a>
															<a href="#" class="btn btn-danger btn-sm" title="non-aktif"><i class="la la-power-off"></i></i></a>
														</td>
													</tr>
													<?php
												}
											}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
